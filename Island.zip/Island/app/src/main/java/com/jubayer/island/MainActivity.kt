package com.jubayer.island

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var root: LinearLayout

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(48), dp(16), dp(32))
        }
        setContentView(ScrollView(this).apply {
            setBackgroundColor(0xFF2F2F2F.toInt())
            addView(root)
        })

        button("1. ALLOW DISPLAY OVER OTHER APPS") {
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
        }
        button("2. ALLOW NOTIFICATION ACCESS") {
            startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS))
        }
        button("3. DISABLE BATTERY OPTIMIZATION") {
            try {
                startActivity(
                    Intent(
                        Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS,
                        Uri.parse("package:$packageName")
                    )
                )
            } catch (e: Exception) {
                startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            }
        }
        button("4. LOCK SCREEN MODE (ACCESSIBILITY)") {
            Toast.makeText(this, "Installed services > Island (Lock screen mode) > ON", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        button("5. START ISLAND") {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Age step 1 koro", Toast.LENGTH_SHORT).show()
                return@button
            }
            if (Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
            Prefs.set(this, "enabled", 1)
            startForegroundService(Intent(this, IslandService::class.java))
        }
        button("STOP ISLAND") {
            Prefs.set(this, "enabled", 0)
            stopService(Intent(this, IslandService::class.java))
        }
        button("TEST ISLAND") { IslandHost.notify("Island working ✓") }

        slider("Upor-niche (Y)", "y", 0, 300, 8)
        slider("Bame-dane (X)", "x", -200, 200, 0)
        slider("Chora (Width)", "w", 40, 300, 103)
        slider("Uchota (Height)", "h", 16, 80, 29)

        button("RESET POSITION") {
            Prefs.clearPosition(this)
            IslandHost.refresh()
            recreate()
        }
    }

    private fun button(label: String, onClick: () -> Unit) {
        val b = Button(this).apply {
            text = label
            setOnClickListener { onClick() }
        }
        root.addView(
            b,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                .apply { bottomMargin = dp(8) }
        )
    }

    private fun slider(label: String, key: String, lo: Int, hi: Int, def: Int) {
        val title = TextView(this).apply {
            setTextColor(0xFFDDDDDD.toInt())
            textSize = 16f
            setPadding(0, dp(16), 0, 0)
        }
        val start = Prefs.get(this, key, def)
        title.text = "$label: $start"
        val bar = SeekBar(this)
        bar.max = hi - lo
        bar.progress = start - lo
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                val v = p + lo
                title.text = "$label: $v"
                Prefs.set(this@MainActivity, key, v)
                IslandHost.refresh()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        root.addView(title)
        root.addView(bar)
    }
}
