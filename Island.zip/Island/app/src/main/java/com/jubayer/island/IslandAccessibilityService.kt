package com.jubayer.island

import android.accessibilityservice.AccessibilityService
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent

// Lock screen + notification shade er upore dekhanor jonno (TYPE_ACCESSIBILITY_OVERLAY)
class IslandAccessibilityService : AccessibilityService() {

    private var controller: IslandController? = null

    override fun onServiceConnected() {
        super.onServiceConnected()
        controller = IslandController(this, WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY)
        controller?.show()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onDestroy() {
        controller?.hide()
        super.onDestroy()
    }
}
