package com.jubayer.island

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        if (Prefs.get(context, "enabled", 0) == 1) {
            try {
                context.startForegroundService(Intent(context, IslandService::class.java))
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}
